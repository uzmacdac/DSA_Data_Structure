
class StringBinaryTree{
	
	Node root;

	class Node{
		
		String str;
		Node left;
		Node right;
		
		Node(String str){
			this.str = str;
		}
		
	}
	
	static boolean isLesser(String prev, String current){			// comparing two string to check is current string is lesser or not
		for(int i = 0; i < current.length(); i++){
			if(current.charAt(i) == prev.charAt(i)){
				if(i == current.length() - 1 ){
					return true;
				}
				//continue;
			}
			else if(current.charAt(i) < prev.charAt(i)){
				return true;
			}
			else{
				return false;
			}
		}
		return false;
	}
	
	void add(String str){
		root = addString(root, str);
	}
	
	Node addString(Node root, String str){
		
		if(root == null){
			root = new Node(str);
			return root;
		}
		
		if(isLesser(root.str, str)){
			root = addString(root.left, str);
		}
		else{
			root = addString(root.right, str);
		}
		
		return root;
	}
	
	void preOrder(){
		root = preOrderPrint(root);
	}
	
	Node preOrderPrint(Node root){
		if(root == null){
			return root;
		}
		
		System.out.println(root.str);
		preOrderPrint(root.left);
		preOrderPrint(root.right);
		return root;
	}
	
	void inOrder(){
		root = inOrderPrint(root);
	}
	
	Node inOrderPrint(Node root){
		if(root == null){
			return root;
		}
		
		inOrderPrint(root.left);
		System.out.println(root.str);
		inOrderPrint(root.right);
		return root;
	}
	
	public static void main(String [] args){
		StringBinaryTree tree = new StringBinaryTree();
		tree.add("vivek  qjadiyar");
		tree.add("vipul");
		tree.add("ankit");
		tree.add("vishal");
		tree.add("ratish");
		tree.add("sagar");
		tree.add("vivek naik");
		
		//Node n = new Node("viekv");
		
		System.out.println("Pre Order: ");
		tree.preOrder();
		System.out.println("\n");
		System.out.println("In Order: ");
		tree.inOrder();
		
		
	}

}