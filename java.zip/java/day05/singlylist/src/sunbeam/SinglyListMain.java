package sunbeam;

public class SinglyListMain {
	public static void main(String[] args) {
		
	}
}
