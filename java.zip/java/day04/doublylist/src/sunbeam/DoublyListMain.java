package sunbeam;

public class DoublyListMain {
	public static void main(String[] args) {
		DoublyList list = new DoublyList();
		list.displayFwd();
		list.displayRev();
	}
}
