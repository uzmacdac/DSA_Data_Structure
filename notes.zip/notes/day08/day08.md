# Data Structures and Algorithms

## Agenda
* Binary Search Tree
* Types of Trees

