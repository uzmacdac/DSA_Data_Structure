#include <stdio.h>

int main() {
	printf("Hello Data Structure & Algorithms!!\n");
	return 0;
}
