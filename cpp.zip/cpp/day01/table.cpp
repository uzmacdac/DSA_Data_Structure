#include <stdio.h>

int main() {
	int n, i;
	printf("enter a number: ");
	scanf("%d", &n);
	//for (i = 1; i <= 10; i++) {
	//	printf("%d, ", n * i);
	//}
	printf("%d, ", n * 1);
	printf("%d, ", n * 2);
	printf("%d, ", n * 3);
	printf("%d, ", n * 4);
	printf("%d, ", n * 5);
	printf("%d, ", n * 6);
	printf("%d, ", n * 7);
	printf("%d, ", n * 8);
	printf("%d, ", n * 9);
	printf("%d, ", n * 10);
	return 0;
}

